ant build
sudo cp servlet.war /usr/share/jetty/webapps
sudo java -jar /usr/share/jetty/start.jar

