ant build
sudo cp servlet.war /usr/share/jetty/webapps
